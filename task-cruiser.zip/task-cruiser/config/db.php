<?php
//  Takes the global variables
require("config.php");

//  Creates a mysqli connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

//  Returns a message if the connection is successfull or unsuccessfull
if (!$conn) {
    echo "<font color='red'>Connection Failed</font>";
    die();
}