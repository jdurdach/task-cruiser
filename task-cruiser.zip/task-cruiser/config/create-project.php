<?php

//  Check that the form has been submitted
if (isset($_POST["new-project-submit"])) {
    //  Establish connection and start session
    require("db.php");
    session_start();

    //  Delcare session variables
    $track_id = $_SESSION["track_id"];
    $username = $_SESSION["username"];

    //  Assign input values to variables
    $new_project_name = $_POST["new-project-name"];
    $new_project_completed = 0;
    $new_project_description = $_POST["new-project-description"];
    $new_project_priority = $_POST["new-project-priority"];

    //  If the user did not enter a name, they are redirected back to the project page and $_GET["error"] = nonewprojectname
        //  There is an if statement on the project page that will handle the incoming $_GET["error"] value and display a message
    if (empty($new_project_name)) {
        header("Location:  ../projects.php?error=nonewprojectname&username=".$username);
        exit();
    } else {
        //  Check that there are no projects with the same name for that track id
        $sql = "SELECT project_id FROM projects WHERE project_name=? AND track_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('ss', $new_project_name, $track_id);
        $stmt->execute();
        $stmt->bind_result($found_project);
        $stmt->fetch(); 

        //  If the project has already been created, the user is redirected back with a $_GET["error"] and an if statement handles the response
        if ($found_project) {
            header("Location:  ../projects.php?error=duplicateproject&username=".$username);
            exit();
        } else {
            //  If everything works, then the database is updated and the user is redirected to the projects page, where they can seee their new project
            $sql='insert into `projects` (`project_name`, `project_description`, `completed`, `priority`, `track_id`) values (?, ?,?,?,?);';
            $stmt=$conn->prepare( $sql );
            $stmt->bind_param('sssss', $new_project_name, $new_project_description, $new_project_completed, $new_project_priority, $track_id);
            $stmt->execute();

            //  Sends a confirmation message in $_GET["create-project"] that an if statement will handle
            header("Location:  ../projects.php?create-project=success&username=".$username."&track=".$_SESSION["track_id"]."&name=".$_SESSION["track_name"]);
            exit();
        }
    }
}

?>