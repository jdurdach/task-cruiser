<?php

//  Check that the form has been submitted
if (isset($_POST["new-task-submit"])) {
    //  Establish connection and start session
    require("db.php");
    session_start();

    //  Delcare session variables
    $project_id = $_SESSION["project_id"];
    $username = $_SESSION["username"];

    //  Assign input values to variables
    $new_task_name = $_POST["new-task-name"];
    $new_task_completed = 0;
    $new_task_description = $_POST["new-task-description"];
    $new_task_priority = $_POST["new-task-priority"];

    //  If the user did not enter a name, they are redirected back to the project page and $_GET["error"] = nonewprojectname
        //  There is an if statement on the project page that will handle the incoming $_GET["error"] value and display a message
    if (empty($new_task_name)) {
        header("Location:  ../tasks.php?error=nonewtaskname&username=".$username);
        exit();
    } else {
        //  Check that there are no projects with the same name for that track id
        $sql = "SELECT task_id FROM tasks WHERE task_name=? AND project_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('ss', $new_task_name, $project_id);
        $stmt->execute();
        $stmt->bind_result($found_task);
        $stmt->fetch(); 

        //  If the project has already been created, the user is redirected back with a $_GET["error"] and an if statement handles the response
        if ($found_task) {
            header("Location:  ../tasks.php?error=duplicatetask&username=".$username);
            exit();
        } else {
            //  If everything works, then the database is updated and the user is redirected to the projects page, where they can seee their new project
            $sql='insert into `tasks` (`task_name`, `task_description`, `completed`, `priority`, `project_id`) values (?, ?,?,?,?);';
            $stmt=$conn->prepare( $sql );
            $stmt->bind_param('sssss', $new_task_name, $new_task_description, $new_task_completed, $new_task_priority, $project_id);
            $stmt->execute();

            //  Sends a confirmation message in $_GET["create-project"] that an if statement will handle
            header("Location:  ../tasks.php?create-task=success&username=".$username."&project=".$_SESSION["project_id"]."&name=".$_SESSION["project_name"]);
            exit();
        }
    }
}

?>