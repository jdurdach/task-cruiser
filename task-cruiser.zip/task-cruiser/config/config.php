<?php 
    //  Define global variables for db and host info
    define("ROOT_URL", "/task-cruiser/");
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "task_cruiser");
