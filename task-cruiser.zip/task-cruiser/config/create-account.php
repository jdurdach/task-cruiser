<?php

//  Check that the form has been submitted
if (isset($_POST["signup-submit"])) {
    //  Establish connection
    require("db.php");

    //  Set input values to variables
    $new_fname = $_POST["signup-fname"];
    $new_lname = $_POST["signup-lname"];
    $new_email = $_POST["signup-email"];
    $new_username = $_POST["signup-username"];
    $new_password = $_POST["signup-password"];
    $new_password_confirm = $_POST["signup-password-confirm"];

    //  Input validation statements
    //  When the user enters information, they will be redirected to an error or confirmation page
    if (empty($new_fname) || empty($new_lname) || empty($new_email) || empty($new_username) || empty($new_password) || empty($new_password_confirm)) {
        //  Empty fields
        header("LOCATION:  ".ROOT_URL."signup.php?error=emptyfields");
        exit();
    } else if (!filter_var($new_email, FILTER_VALIDATE_EMAIL) || !preg_match("/^[a-zA-Z0-9]*$/", $new_username)){
        //  Invalid username or password
        header("LOCATION:  ".ROOT_URL."signup.php?error=invalid");
        exit();
    } else if ($new_password !== $new_password_confirm) {
        //  Password mismatch
        header("LOCATION:  ".ROOT_URL."signup.php?error=password");
        exit();
    } else {

        //  Check that the new username isn't taken - https://stackoverflow.com/questions/38671619/php-and-mysql-check-if-username-is-already-taken
        $sql = "SELECT username FROM users WHERE username=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s',$new_username);
        $stmt->execute();
        $stmt->bind_result($found_username);
        $stmt->fetch();   
        
        if ($found_username) {
            //  If the username is taken, the user is redirected to an error page
            header("LOCATION:  ".ROOT_URL."signup.php?error=usernametaken");
            exit();
        } else {
            //  If the username is not taken, the database is updated and the user is redirected to a confirmation page
            $sql='insert into `users` (`first_name`,`last_name`,`email`,`username`,`password`) values (?,?,?,?,?);';
            $stmt=$conn->prepare( $sql );
            $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt->bind_param('sssss',$new_fname, $new_lname, $new_email, $new_username, $new_password_hashed);
            $stmt->execute();

            header("LOCATION:  ".ROOT_URL."signup.php?create=success");
            exit();
        }
    }
}