<?php

//  Check that the form has been submitted
if (isset($_POST["new-track-submit"])) {
    //  Establish connection and start session
    require("db.php");
    session_start();

    //  Declare session variables
    $user_id = $_SESSION["id"];
    $username = $_SESSION["username"];

    //  Assign user input into variables
    $new_track_name = $_POST["new-track-name"];
    $new_track_completed = 0;
    $new_track_description = $_POST["new-track-description"];

    //  If the user did not enter a name, they are redirected back to the project page and $_GET["error"] = nonewtrackname
        //  There is an if statement on the project page that will handle the incoming $_GET["error"] value and display a message
    if (empty($new_track_name)) {
        header("Location:  ../tracks.php?error=nonewtrackname&username=".$username);
        exit();
    } else {
        //  Check that there are no tracks with the same name for that user id
        $sql = "SELECT track_id FROM tracks WHERE track_name=? AND user_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('ss', $new_track_name, $user_id);
        $stmt->execute();
        $stmt->bind_result($found_track);
        $stmt->fetch(); 

        //  If the track has already been created, the user is redirected back with a $_GET["error"] and an if statement handles the response
        if ($found_track) {
            header("Location:  ../tracks.php?error=duplicatetrack&username=".$username);
            exit();
        } else {
            //  If everything works, then the database is updated and the user is redirected to the tracks page, where they can seee their new track
            $sql='insert into `tracks` (`user_id`, `track_name`,`completed`,`track_description`) values (?,?,?,?);';
            $stmt=$conn->prepare( $sql );
            $stmt->bind_param('ssss',$user_id, $new_track_name, $new_track_completed, $new_track_description);
            $stmt->execute();

            //  Sends a confirmation message in $_GET["create-track"] that an if statement will handle
            header("Location:  ../tracks.php?create-track=success&username=".$username);
            exit();
        }
    }
}

?>