<?php

//  Checks that the form has been submitted
if (isset($_POST["login-submit"])) {
    //  Establishes connection
    require("db.php");

    //  Assigns user input to variables
    $username_entry = $_POST["login-username"];
    $password_entry = $_POST["login-password"];

    //  If the user did not enter a username or password, they are redirected back to the index page and $_GET["error"] = emptyfields
        //  There is an if statement on the page that will handle the incoming $_GET["error"] value and display a message
    if (empty($username_entry) || empty($password_entry)) {
        header("Location:  ../index.php?error=emptyfields&username=".$username);
        exit();  
    } else {
        //  Validates the SQL
        $sql = "SELECT * FROM users WHERE username =?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location:  ../index.php?error=sqlerror");
            exit(); 
        } else {
            //  Checks that the username is in the database
            mysqli_stmt_bind_param($stmt, "s", $username_entry); 
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                //  If the username is found, this checks that the passwords match
                $password_check = password_verify($password_entry, $row['password']);
                if ($password_check == false) {
                    header("Location:  ../index.php?error=incorrectpassword&username=".$username_entry);
                    exit(); 
                } else if ($password_check == true) {
                    //  If everything works, this declares session variables with the user id and username
                    session_start();
                    $_SESSION["id"] = $row["user_id"];
                    $_SESSION["username"] = $row["username"];

                    header("Location:  ../tracks.php?login=success&username=".$username_entry);
                    exit();                    
                } else {
                    //  Redirects the user back with an error if the password is incorrect
                    header("Location:  ../index.php?error=incorrectpassword&username=".$username_entry);
                    exit(); 
                }
            } else {
                //  Redirects the user back with an error if there is no username
                header("Location:  ../index.php?error=nouser&username=".$username_entry);
                exit(); 
            }
        }
    }
} else {
    header("Location:  ../index.php");
    exit();  
}


?>