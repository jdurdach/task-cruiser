<!-- Imports the header -->
<?php require("include/header.php"); ?>

<main>
<div id="container">
<?php 
    //  if statement to validate an error messages
    if (isset($_GET["error"])) {
        if ($_GET["error"] == "emptyfields") {
            echo "<h3>PLEASE COMPLETE ALL FIELDS<h3>";
        } else if ($_GET["error"] == "incorrectpassword" || $_GET["error"] == "nouser") {
            echo "<h3>INCORRECT USERNAME OR PASSWORD<h3>";
        }
    }
?>
<br>
<div id="info">
<h1>Welcome to Task Cruiser!</h1>
<p>Please login or create an account.</p>

<h2>What is Task Cruiser?</h2>
<p>Task Cruiser is a simple productivity tool that allows you to break-down different portions of your workflow into tracks, project, and tasks.</p>
<p>I built Task Cruiser in 2020 for my Senior Capstone Project as a student at Keystone College.</p>

<h2>What are tracks?</h2>
<p>Think of tracks as the different areas of your life that require your attention and organization.</p>
<p>Examples include "Schoolwork," "Work," "Exercise," "Side-Hustle," and "Personal Development."</p>

<h2>What are projects and tasks?</h2>
<p>Projects are all of the different elements that you must balance within a certain track.  Tasks are the listed actions that you must take to manage your projects.</p>
<p>For example, if you have a track called "Schoolwork," you may have projects such as "Math" and "English."</p>
<p>Tasks within those projects may include things like "Study Chapter 3," "Finish homework problems," and "Start writing research paper."</p>

<h2>How does Task Cruiser work?</h2>
<p>Task Cruiser uses PHP to communicate with a database to fetch information, create new entries, and more!</p>
<p>I built Task Cruiser to run on a web server and allow users to access information from anywhere with an internet connection!</p>
<p>Task Cruiser is a constantly changing project that will grow and improve through time.  New features should emerge in the future.</p>

<h2>Acknowledgements</h2>
<p>This project would not have been possible without the instruction, advice, and support from Dr. Rob Nardelli, Terry O'Brien, Rob Rutkowski, Brad Traversy, and Mike Dane.</p>
<p>I would like to thank those individuals, as well as my other professors and fellow classmates for their instruction and guidance along the way.</p>
<p><em>Google, Stack Overflow, and YouTube played a part as well...</em></p>
<br/>






</div>
</main>

<!-- Imports the footer -->
<?php require("include/footer.php"); ?>