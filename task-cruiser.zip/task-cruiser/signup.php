<!-- Imports the header -->
<?php require("include/header.php"); ?>
<br/>

<!-- Simple form to pass values to config/signup.php -->
<form name="signup-form" method="POST" action="config/create-account.php">
    <input type="text" name="signup-fname" placeholder="First Name">
    <input type="text" name="signup-lname" placeholder="Last Name"><br/>
    <input type="text" name="signup-email" placeholder="Email">
    <input type="text" name="signup-username" placeholder="Username"><br/>
    <input type="password" name="signup-password" placeholder="Password">
    <input type="password" name="signup-password-confirm" placeholder="Confirm Password"><br/>
    <button type="submit" name="signup-submit">Create Account</button>
</form>
<br/>

<div id="container">

<!-- Error messages -->
<?php 
    if (isset($_GET["error"])) {
        if ($_GET["error"] == "emptyfields") {
        echo "<h3>ERROR:  EMPTY FIELDS</h3>";
        } else if ($_GET["error"] == "invalid") {
            echo "<h3>ERROR:  INVALID EMAIL</h3>";
        } else if ($_GET["error"] == "password") {
            echo "<h3>ERROR:  PASSWORDS DO NOT MATCH</h3>";
        } else if ($_GET["error"] == "usernametaken") {
            echo "<h3>ERROR:  USERNAME IN USE</h3>";
        } 
    }

    if (isset($_GET["create"]) && $_GET["create"] == "success") {
            echo "<h3>REGISTERED SUCCESSFULLY</h3>";
    }

?>

<!-- Imports the footer -->
<?php require("include/footer.php"); ?>