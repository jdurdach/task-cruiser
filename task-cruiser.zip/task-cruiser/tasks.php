<!-- Imports the header -->
<?php require("include/header.php"); ?>

<main>
    <!-- Fetch from database -->
    <?php 
        //  Starts session and declares a local variable user_id equal to the session variable id
        session_start();
        $user_id = $_SESSION["id"];



        //  Takes the values from $_GET variables to locate the track name and track id and assigns them to $_SESSION variables
        if (isset($_GET["project"])) {
            $_SESSION["project_id"] = $_GET["project"];
        }
        if (isset($_GET["name"])) {
            $_SESSION["project_name"] = $_GET["name"];
        }
        if (isset($_GET["project-completion"])) {
            $_SESSION["project_completion"] = $_GET["project-completion"];
        }

        //  SQL Query to database
        $sql = "SELECT * FROM tasks WHERE project_id =".$_SESSION["project_id"];
        //  Get result
        $result = mysqli_query($conn, $sql);
        //  Fetch data (associative array)
        $tasks = mysqli_fetch_all($result, MYSQLI_ASSOC);
        //  Free result from memory
        mysqli_free_result($result);
        //  Close connection
        mysqli_close($conn);
    ?>
    <!-- Displays a little information about the user and their selected project.  Also provides a button link to edit the project -->
    <div id="container">
    <p>Signed-in as <?php echo $_SESSION["username"]; ?></p>
    <a href="<?php echo ROOT_URL; ?>projects.php"><button>Return to Projects</button></a>
    <h1>Tasks</h1>
    <h2><?php echo $_SESSION["project_name"]; ?></h2>
    <p>Completion Status:  <?php if ($_SESSION["project_completion"] == 0) {echo "Not Completed";} else {echo "Completed";} ?></p>
    <a href="<?php echo ROOT_URL; ?>include/edit-project.php?toggle=yes"><button>Toggle Completion</button></a>
    <a href="<?php echo ROOT_URL; ?>include/edit-project.php"><button>Edit Project</button></a>
    <hr/>


    <!-- Show Tasks -->
    <?php foreach($tasks as $task) : ?>
        <h4><?php echo $task["task_name"]; ?></h4>
        <p><?php echo $task["task_description"]; ?></p>
        <p>Priority:  <?php echo $task["priority"]; ?></p>
        <p>Completion Status:  <?php if ($task["completed"] == 0) {echo "Not Completed";} else {echo "Completed";} ?></p>
        <a href="<?php echo ROOT_URL; ?>include/edit-task.php?function=complete&task=<?php echo $task["task_id"]; ?>&completion=<?php echo $task["completed"]; ?>">
        <button>Toggle Completion</button></a> 
        <a href="<?php echo ROOT_URL; ?>include/edit-task.php?function=delete&task=<?php echo $task["task_id"]; ?>">
        <button>Delete Task</button></a>
        <hr/>
    <?php endforeach; ?>

    <!-- Create Task Form -->
    <form name="new-project" method="POST" action="<?php echo ROOT_URL ?>config/create-task.php">
        <input type="text" name="new-task-name" placeholder="Task Name"><br/>
        <textarea name="new-task-description" placeholder="task Description"></textarea><br/>
        <label>Priority</label>
        <input type="radio" id="1" name="new-task-priority" value="1" style="width: 20px;">
        <label for="1">1</label>
        <input type="radio" id="2" name="new-task-priority" value="2" style="width: 20px;">
        <label for="2">2</label>
        <input type="radio" id="3" name="new-task-priority" value="3" style="width: 20px;" checked>
        <label for="3">3</label><br/><br/>
        <button type="submit" name="new-task-submit">Create New Task</button>
    </form>
    <br/>


    <!-- Error Messages UPDATE -->
    <?php 
    if (empty($_GET["error"])) {
    } else if ($_GET["error"] == "nonewtaskname") {
        echo "ERROR:  PLEASE ENTER A TASK NAME";
    } else if ($_GET["error"] == "duplicatetask") {
        echo "ERROR:  TASK ALREADY EXISTS";
    }

    if (empty($_GET["create-task"])) {
    } else if ($_GET["create-task"] == "success") {
        echo "TASK CREATED SUCCESSFULLY";
    }
    ?>

</main>

<!-- Import footer -->
<?php require("include/footer.php"); ?>