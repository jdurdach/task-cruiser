<?php require("include/header.php"); ?>

<main>
    <!-- Fetch from database -->
    <?php 
        //  Starts session and declares a local variable user_id equal to the session variable id
        session_start();
        $user_id = $_SESSION["id"];

        //  SQL Query to database
        $sql = "SELECT * FROM tracks WHERE user_id =".$user_id;
        //  Get result
        $result = mysqli_query($conn, $sql);
        //  Fetch data (associative array)
        $tracks = mysqli_fetch_all($result, MYSQLI_ASSOC);
        //  Free result from memory
        mysqli_free_result($result);
        //  Close connection
        mysqli_close($conn);
    ?>

    <!-- Displays a little information about the user and their tracks. -->
    <div id="container">
    <p>Signed-in as <?php echo $_SESSION["username"]; ?></p>
    <h1>Tracks</h1>
    <?php if(isset($_GET["delete"])) {echo "<p>TRACK SUCCESSFULLY DELETED</p>"; } ?>
    <hr/>
    <?php foreach($tracks as $track) : ?>
        <h3><?php echo $track["track_name"]; ?></h3>
        <div id="description">
            <p><?php echo $track["track_description"]; ?></p>
            <a href="projects.php?track=<?php echo $track['track_id']; ?>&name=<?php echo $track['track_name']; ?>"><button>View Track</button></a>
        </div>
        <hr/>
    <?php endforeach; ?>

    <!-- Create Track Form -->
    <form name="new-track" method="POST" action="<?php echo ROOT_URL ?>config/create-track.php">
        <input type="text" name="new-track-name" placeholder="Track Name"><br/>
        <textarea name="new-track-description" placeholder="Track Description"></textarea><br/>
        <button type="submit" name="new-track-submit">Create New Track</button>
    </form>
    <br/>

    <!-- Error message -->
    <?php 
    if (empty($_GET["error"])) {
    } else if ($_GET["error"] == "nonewtrackname") {
        echo "ERROR:  PLEASE ENTER A TRACK NAME";
    } else if ($_GET["error"] == "duplicatetrack") {
        echo "ERROR:  TRACK ALREADY CREATED";
    }

    if (empty($_GET["create-track"])) {
    } else if ($_GET["create-track"] == "success") {
        echo "TRACK CREATED SUCCESSFULLY";
    }
    ?>

</main>

<!-- Import footer -->
<?php require("include/footer.php"); ?>