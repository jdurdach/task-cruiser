<!-- Imports the header -->
<?php require("include/header.php"); ?>

<main>
    <!-- Fetch from database -->
    <?php 
        //  Starts session and declares a local variable user_id equal to the session variable id
        session_start();
        $user_id = $_SESSION["id"];

        //  Takes the values from $_GET variables to locate the track name and track id and assigns them to $_SESSION variables
        if (isset($_GET["track"])) {
            $_SESSION["track_id"] = $_GET["track"];
        }
        if (isset($_GET["name"])) {
            $_SESSION["track_name"] = $_GET["name"];
        }

        //  SQL Query to database
        $sql = "SELECT * FROM projects WHERE track_id =".$_SESSION["track_id"];
        //  Get result
        $result = mysqli_query($conn, $sql);
        //  Fetch data (associative array)
        $projects = mysqli_fetch_all($result, MYSQLI_ASSOC);
        //  Free result from memory
        mysqli_free_result($result);
        //  Close connection
        mysqli_close($conn);
    ?>
    <!-- displays a little information about the user and their selected track.  Also provides a button link to edit the track -->
    <div id="container">
    <p>Signed-in as <?php echo $_SESSION["username"]; ?></p>
    <a href="<?php echo ROOT_URL; ?>tracks.php"><button>Return to Tracks</button></a>
    <h1>Projects</h1>
    <h2><?php echo $_SESSION["track_name"]; ?></h2>
    <a href="<?php echo ROOT_URL; ?>include/edit-track.php"><button class="edit-button">Edit Track</button></a>
    <hr/>


    <!-- Show Projects -->
    <?php foreach($projects as $project) : ?>
        <h4><?php echo $project["project_name"]; ?></h4>
        <div class="description">
            <p><?php echo $project["project_description"]; ?></p>
            <p class="priority">Priority:  <?php echo $project["priority"]; ?></p>
            <p class="completion">Completion Status:  <?php if ($project["completed"] == 0) {echo "Not Completed";} else {echo "Completed";} ?></p>
        </div>
        <a href="tasks.php?project=<?php echo $project['project_id']; ?>&name=<?php echo $project['project_name']; ?>&project-completion=<?php echo $project["completed"]; ?>"><button>View Project</button></a>
        <hr/>
    <?php endforeach; ?>

    <!-- Create Project Form -->
    <form name="new-project" method="POST" action="<?php echo ROOT_URL ?>config/create-project.php">
        <input type="text" name="new-project-name" placeholder="Project Name"><br/>
        <textarea name="new-project-description" placeholder="Project Description"></textarea><br/>
        <label>Priority</label>
        <input type="radio" id="1" name="new-project-priority" value="1" style="width: 20px;">
        <label for="1">1</label>
        <input type="radio" id="2" name="new-project-priority" value="2" style="width: 20px;">
        <label for="2">2</label>
        <input type="radio" id="3" name="new-project-priority" value="3" style="width: 20px;" checked>
        <label for="3">3</label>    <br/><br/>
        <button type="submit" name="new-project-submit">Create New Project</button>
    </form>
    <br/>


    <!-- Error Messages UPDATE -->
    <?php 
    if (empty($_GET["error"])) {
    } else if ($_GET["error"] == "nonewprojectname") {
        echo "ERROR:  PLEASE ENTER A PROJECT NAME";
    } else if ($_GET["error"] == "duplicateproject") {
        echo "ERROR:  PROJECT ALREADY EXISTS";
    }

    if (empty($_GET["create-project"])) {
    } else if ($_GET["create-project"] == "success") {
        echo "PROJECT CREATED SUCCESSFULLY";
    }
    ?>

</main>

<!-- Import footer -->
<?php require("include/footer.php"); ?>