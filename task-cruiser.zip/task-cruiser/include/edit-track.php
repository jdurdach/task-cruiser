<?php
require("alt-header.php");
session_start();

$sql = "SELECT * FROM tracks WHERE track_id =".$_SESSION["track_id"];
//  Get result
$result = mysqli_query($conn, $sql);
//  Fetch data (associative array)
$track = mysqli_fetch_all($result, MYSQLI_ASSOC);
//  Free result from memory
mysqli_free_result($result);
//  Close connection

foreach ($track as $track) {

}

?>

<div id="container">

<h1>Edit Track:  <?php echo $_SESSION["track_name"]; ?></h1>
<form name="edit-track-form" action="edit-track.php" method="POST">
    <!-- <label for="edit-track-name">Track Name:  </label> -->
    <input type="text" name="edit-track-name" value="<?php echo $track['track_name']; ?>"><br/><br/>
    <!-- <label for="edit-track-description">Track Description:  </label> -->
    <textarea name="edit-track-description"><?php echo $track['track_description']; ?></textarea><br/><br/>
    <button type="submit" name="edit-track-name-submit">Save Changes</button>
</form>
<br/>
<a href="delete-track.php?track=<?php echo $track["track_id"]; ?>"><button>Delete Track</button></a>
<br/><br/>
<a href="<?php echo ROOT_URL; ?>projects.php"><button>Return to Projects</button></a>
    
<?php

if(isset($_POST["edit-track-name-submit"])) {
    $edit_track_name = $_POST["edit-track-name"];
    $edit_track_description = $_POST["edit-track-description"];
    $track_id = $_SESSION["track_id"];
    
    $sql = "UPDATE tracks SET track_name=?, track_description=? WHERE track_id=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param('sss', $edit_track_name, $edit_track_description, $track_id);
    $stmt->execute();

    header("LOCATION:  ".ROOT_URL."tracks.php");
    exit();
}

?>