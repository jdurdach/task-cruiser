<?php
require("alt-header.php");
session_start();
?>

<!-- Confirmation form to validate deletion -->
<div id="container">
<h1>Are you sure that you want to delete track <?php echo $_SESSION["track_name"]; ?>?</h1>
<form name="delete-track-form" method="POST" action="delete-track.php">
    <button type="submit" name="delete-track-submit">Yes, delete track</button>
</form>
<br/>
<a href="<?php echo ROOT_URL; ?>projects.php"><button>No, return to projects</button></a>

<?php
//  Get track id
$track = $_SESSION["track_id"];

if (isset($_POST["delete-track-submit"])) {
    //  Get all of the projects in an associative array
    $sql = "SELECT * FROM projects WHERE track_id = ".$track;
    //  Get result
    $result = mysqli_query($conn, $sql);
    //  Fetch data (associative array)
    $projects = mysqli_fetch_all($result, MYSQLI_ASSOC);

    //  Loop through and delete all the task for each project
    foreach($projects as $project) {
        $sql = "DELETE FROM tasks WHERE project_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $project["project_id"]);
        $stmt->execute();
    }

        //  Delete all projects for the track
        $sql = "DELETE FROM projects WHERE track_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $track);
        $stmt->execute();

        //  Delete the track
        $sql = "DELETE FROM tracks WHERE track_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $track);
        $stmt->execute();

        header("LOCATION:  ".ROOT_URL."tracks.php?delete=success");
        exit();
}

?>

