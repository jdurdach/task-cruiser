<!DOCTYPE html>
<html>
<head>
    <title>Task Cruiser!</title>
    <link rel="stylesheet" href="styles.css" type="text/css" />
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap" rel="stylesheet">
</head>
<body>
<!--    Establishes connection -->
<?php require("config/db.php"); ?>
<header>
    <!-- Login form -->
    <form name="login-form" method="POST" action="config/login.php" style="display:  inline;">
        <input type="text" name="login-username" placeholder="Username">
        <input type="password" name="login-password" placeholder="Password">
        <button type="submit" name="login-submit">Login</button>
        <a href="<?php echo ROOT_URL.'logout.php'; ?>"><button>Logout</button></a>
    </form>
     <!--   <a href="<?php echo ROOT_URL.'signup.php'; ?>"><button>Signup</button></a> -->
        <a href="signup.php"><button>Signup</button></a>
</header>
<hr/>