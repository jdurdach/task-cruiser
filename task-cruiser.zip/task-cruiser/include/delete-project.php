<?php
require("alt-header.php");
session_start();
?>

<div id="container">

<h1>Are you sure that you want to delete project <?php echo $_SESSION["project_name"]; ?>?</h1>
<form name="delete-project-form" method="POST" action="delete-project.php">
    <button type="submit" name="delete-project-submit">Yes, delete project</button>
</form>
<br/>
<a href="<?php echo ROOT_URL; ?>tasks.php"><button>No, return to tasks</button></a>

<?php

$project = $_SESSION["project_id"];

if (isset($_POST["delete-project-submit"])) {
    $sql = "DELETE FROM tasks WHERE project_id=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param('s', $project);
    $stmt->execute();

    $sql = "DELETE FROM projects WHERE project_id=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param('s', $project);
    $stmt->execute();

    header("LOCATION:  ".ROOT_URL."projects.php");
    exit();
}

?>

