<?php
require("alt-header.php");
session_start();

$sql = "SELECT * FROM projects WHERE project_id =".$_SESSION["project_id"];
//  Get result
$result = mysqli_query($conn, $sql);
//  Fetch data (associative array)
$project = mysqli_fetch_all($result, MYSQLI_ASSOC);
//  Free result from memory
mysqli_free_result($result);
//  Close connection

foreach ($project as $project) {

}

if (isset($_GET["toggle"])) {

    if ($_SESSION["project_completion"] == 0) {
        $sql = "UPDATE projects SET completed = 1 WHERE project_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $project["project_id"]);
        $stmt->execute();

        header("LOCATION:  ".ROOT_URL."tasks.php?project-completion=1");
        exit();
    } else if ($_SESSION["project_completion"] == 1) {
        $sql = "UPDATE projects SET completed = 0 WHERE project_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $project["project_id"]);
        $stmt->execute();

        header("LOCATION:  ".ROOT_URL."tasks.php?project-completion=0");
        exit();
    }
}

?>

<div id="container">

<h1 class="heading">Edit Project:  <?php echo $_SESSION["project_name"]; ?></h1>
<form name="edit-project-form" action="edit-project.php" method="POST">
    <input type="text" name="edit-project-name" value="<?php echo $project['project_name']; ?>"><br/><br/>
    <textarea name="edit-project-description"><?php echo $project['project_description']; ?></textarea><br/><br/>
    <button type="submit" name="edit-project-name-submit">Save Changes</button>
</form>
<br/>
    <a href="delete-project.php?project=<?php echo $project["project_id"]; ?>"><button>Delete Project</button></a>
<br/><br/>
<a href="<?php echo ROOT_URL; ?>tasks.php"><button>Return to Tasks</button></a>
    
<?php

if(isset($_POST["edit-project-name-submit"])) {
    $edit_project_name = $_POST["edit-project-name"];
    $edit_project_description = $_POST["edit-project-description"];
    $project_id = $_SESSION["project_id"];
    
    $sql = "UPDATE projects SET project_name=?, project_description=? WHERE project_id=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param('sss', $edit_project_name, $edit_project_description, $project_id);
    $stmt->execute();

    header("LOCATION:  ".ROOT_URL."projects.php");
    exit();
}

?>