</div>
<footer>
<link href="styles.css" rel="stylesheet" type="text/css" />
<center><p>&copy; 2020 <a href="https://www.markdurdach.com" target="blank">Mark J. Durdach</a> <a href="https://www.keystone.edu" target="blank">Keystone College</a></p></center>
</footer>
</body>
</html>