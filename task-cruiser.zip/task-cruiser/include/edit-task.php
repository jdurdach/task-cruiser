<?php
    require("alt-header.php");
    session_start();

    $task_id = $_GET["task"];
    $completion = $_GET["completion"];

    if ($_GET["function"] == "complete") {

        if ($completion == 0) {
            $sql = "UPDATE tasks SET completed = 1 WHERE  task_id=?";
            $stmt=$conn->prepare($sql);
            $stmt->bind_param('s', $task_id);
            $stmt->execute();

            header("LOCATION:  ".ROOT_URL."tasks.php");
            exit();
        } else if ($completion == 1) {
            $sql = "UPDATE tasks SET completed = 0 WHERE  task_id=?";
            $stmt=$conn->prepare($sql);
            $stmt->bind_param('s', $task_id);
            $stmt->execute();

            header("LOCATION:  ".ROOT_URL."tasks.php");
            exit();
        }
    }

    if ($_GET["function"] == "delete") {
        $sql = "DELETE FROM tasks WHERE  task_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param('s', $task_id);
        $stmt->execute();

        header("LOCATION:  ".ROOT_URL."tasks.php");
        exit();
    }

?>