<?php
//  Establishes connection
require("config/db.php");

// Kills the session, which essentially logs the user out.  If a user tries to navigate to track.php or similar, they will be given errors
    //  This should be updated to a cleaner system in the future, but for now it will work
Session_start();
Session_destroy();

//  Navigates the user back to the homepage
header("Location:  ".ROOT_URL);

?>